"use client";

import { useEffect, useState, type FormEvent } from "react";
import { trackEvent } from "../../lib/analytics";
import { initialAttribution, readAttribution } from "../../lib/attribution";
import { tryCreateBrowserSubmissionId } from "../../lib/browserSubmissionId";
import { timelineOptions } from "../../lib/constants";
import { clean, type Attribution, type LeadSourceSurface } from "../../lib/leadPayload";
import { publicLeadErrorMessage } from "../../lib/publicLeadErrors";
import { LEAD_CONSENT_LANGUAGE_TEXT, LEAD_CONSENT_LANGUAGE_VERSION } from "../../lib/leadConsent";
import { postToWidgetParent } from "../../lib/widgetMessaging";
import { AppointmentRequestCTA } from "./AppointmentRequestCTA";
import { LuxuryCard } from "./LuxuryCard";
import { ProgressBar } from "./ProgressBar";
import { SelectField, TextField } from "./FormField";
import { LeadConsentField } from "./LeadConsentField";

type HomeValueFunnelProps = {
  surface?: LeadSourceSurface;
  compact?: boolean;
  attributionOverrides?: Partial<Attribution>;
};

const stepLabels = ["Address", "Email", "Phone", "Thank you"];
const errorId = "home-value-form-error";

export function HomeValueFunnel({
  surface = "home_value_page",
  compact = false,
  attributionOverrides = {},
}: HomeValueFunnelProps) {
  const [attribution] = useState<Attribution>(() =>
    typeof window === "undefined" ? initialAttribution : readAttribution(attributionOverrides),
  );
  const [submissionId, setSubmissionId] = useState<string | null>(null);
  const [step, setStep] = useState(1);
  const [address, setAddress] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [timeline, setTimeline] = useState(timelineOptions[1]);
  const [consent, setConsent] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);
  const [leadMessage, setLeadMessage] = useState<string | null>(null);
  const [leadReference, setLeadReference] = useState<{ leadId: string | null; sessionId: string | null }>({
    leadId: null,
    sessionId: null,
  });
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    setSubmissionId(tryCreateBrowserSubmissionId());
  }, []);

  function submitAddress(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setFormError(null);
    if (clean(address).length < 5) {
      setFormError("Enter the full property address so Mike can review the right home.");
      return;
    }
    trackEvent("home_value_started", attribution, { funnel_name: "home_value", lead_source_surface: surface });
    trackEvent("funnel_started", attribution, { funnel_name: "home_value", lead_source_surface: surface });
    trackEvent("address_submit", attribution, { funnel_name: "home_value", step_name: "address" });
    trackEvent("address_submitted", attribution, { funnel_name: "home_value", step_name: "address" });
    if (surface === "widget") {
      postToWidgetParent({ type: "askmagicmike:lead_started" }, attribution);
    }
    setStep(2);
  }

  function submitEmail(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setFormError(null);
    if (!email.includes("@") || email.length < 6) {
      setFormError("Enter a valid email for your valuation follow-up.");
      return;
    }
    trackEvent("email_submit", attribution, { funnel_name: "home_value", step_name: "email" });
    trackEvent("contact_submitted", attribution, { funnel_name: "home_value", step_name: "email" });
    setStep(3);
  }

  async function submitPhone(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setFormError(null);
    setLeadMessage(null);

    if (clean(phone).replace(/\D/g, "").length < 10) {
      setFormError("Enter a phone number with area code.");
      return;
    }
    if (!submissionId) {
      setFormError("This browser could not create a secure submission reference. Refresh and try again.");
      return;
    }

    setSubmitting(true);
    trackEvent("phone_submit", attribution, { funnel_name: "home_value", step_name: "phone_timeline" });
    trackEvent("timeline_selected", attribution, { funnel_name: "home_value", timeline });
    trackEvent("contact_submitted", attribution, { funnel_name: "home_value", step_name: "phone" });
    if (consent) trackEvent("consent_accepted", attribution, { funnel_name: "home_value", consent_language_version: LEAD_CONSENT_LANGUAGE_VERSION });

    try {
      const res = await fetch("/api/leads", {
        method: "POST",
        headers: { "Content-Type": "application/json", "Idempotency-Key": submissionId },
        body: JSON.stringify({
          funnel_type: surface === "widget" ? "widget" : "home_value",
          lead_source_surface: surface,
          address: clean(address),
          email: clean(email),
          phone: clean(phone),
          timeline,
          status: "new",
          assigned_agent_id: null,
          widget_session_id: submissionId,
          idempotency_key: submissionId,
          consent,
          consent_email: consent,
          consent_call: consent,
          consent_language_version: LEAD_CONSENT_LANGUAGE_VERSION,
          consent_language_text: LEAD_CONSENT_LANGUAGE_TEXT,
          consent_source: `${surface}:home-value`,
          attribution,
        }),
      });
      const data = (await res.json()) as {
        message?: string;
        error?: string;
        lead_id?: string | null;
        session_id?: string | null;
      };
      if (!res.ok) throw new Error(publicLeadErrorMessage(data.error));
      const idempotentReplay = res.headers.get("X-AMM-Idempotent-Replay") === "1";
      if (!idempotentReplay) {
        trackEvent("lead_created", attribution, { funnel_name: "home_value", step_name: "thank_you" });
        if (surface === "widget") {
          trackEvent("widget_lead_created", attribution, { funnel_name: "home_value" });
          postToWidgetParent({ type: "askmagicmike:lead_created" }, attribution);
        }
      }
      setLeadMessage(
        data.message ||
          "Your request is stored for review. Mike or the approved team will follow up through the contact path you provided.",
      );
      setLeadReference({ leadId: data.lead_id || null, sessionId: data.session_id || null });
      setStep(4);
      trackEvent("thank_you_viewed", attribution, { funnel_name: "home_value" });
    } catch (error) {
      setFormError(publicLeadErrorMessage(error instanceof Error ? error.message : undefined));
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <LuxuryCard className={compact ? "p-4" : "p-5 sm:p-7"}>
      <ProgressBar step={step} labels={stepLabels} />

      {step === 1 ? (
        <form noValidate onSubmit={submitAddress} className="space-y-5" data-amm-step="address">
          <TextField
            label="Property address"
            value={address}
            onChange={(event) => {
              setAddress(event.target.value);
              if (formError) setFormError(null);
            }}
            autoComplete="street-address"
            placeholder="123 Lake Wilson Road, Wilson, NC"
            aria-describedby={formError ? errorId : undefined}
            aria-invalid={Boolean(formError)}
            required
          />
          <button className="amm-primary-button w-full px-5 py-4">
            Continue
          </button>
        </form>
      ) : null}

      {step === 2 ? (
        <form noValidate onSubmit={submitEmail} className="space-y-5" data-amm-step="email">
          <TextField
            label="Email for your valuation follow-up"
            value={email}
            onChange={(event) => {
              setEmail(event.target.value);
              if (formError) setFormError(null);
            }}
            type="email"
            autoComplete="email"
            placeholder="you@example.com"
            aria-describedby={formError ? errorId : undefined}
            aria-invalid={Boolean(formError)}
            required
          />
          <div className="flex gap-3">
            <button
              type="button"
              onClick={() => {
                setFormError(null);
                setStep(1);
              }}
              className="amm-secondary-button px-5 py-4"
            >
              Back
            </button>
            <button className="amm-primary-button flex-1 px-5 py-4">
              Continue
            </button>
          </div>
        </form>
      ) : null}

      {step === 3 ? (
        <form noValidate onSubmit={submitPhone} className="space-y-5" data-amm-step="phone">
          <TextField
            label="Phone"
            value={phone}
            onChange={(event) => {
              setPhone(event.target.value);
              if (formError) setFormError(null);
            }}
            type="tel"
            autoComplete="tel"
            placeholder="252-555-0123"
            aria-describedby={formError ? errorId : undefined}
            aria-invalid={Boolean(formError)}
            required
          />
          <SelectField label="Timeline" value={timeline} onChange={(event) => setTimeline(event.target.value)}>
            {timelineOptions.map((option) => (
              <option key={option}>{option}</option>
            ))}
          </SelectField>
          <LeadConsentField checked={consent} onChange={setConsent} />
          <div className="flex gap-3">
            <button
              type="button"
              onClick={() => {
                setFormError(null);
                setStep(2);
              }}
              className="amm-secondary-button px-5 py-4"
            >
              Back
            </button>
            <button disabled={submitting} aria-busy={submitting} className="amm-primary-button flex-1 px-5 py-4 disabled:opacity-60">
              {submitting ? "Submitting" : "Request Valuation"}
            </button>
          </div>
        </form>
      ) : null}

      {step === 4 ? (
        <div className="space-y-5" data-amm-step="thank-you">
          <h3 className="font-serif text-3xl text-[#f4ead4]">Your request is in.</h3>
          <p className="text-[#d9ceb8]">
            {leadMessage || "Mike will review the property details and follow up with practical next steps."}
          </p>
          <div className="rounded-md border border-[#cda24a33] bg-black/35 p-4">
            <p className="text-xs font-bold uppercase tracking-[0.16em] text-[#e2c06f]">
              What happens next
            </p>
            <ul className="mt-3 space-y-2 text-sm leading-6 text-[#d9ceb8]">
              <li>Mike reviews the address and timing you shared.</li>
              <li>Our Town Properties follows up through your provided contact path.</li>
              <li>You can request a conversation now if you want a faster handoff.</li>
            </ul>
          </div>
          <AppointmentRequestCTA
            leadId={leadReference.leadId}
            sessionId={leadReference.sessionId}
            requestSurface={surface}
            funnelName="home_value"
            attribution={attribution}
          />
          <p className="text-sm leading-6 text-[#d9ceb8]">
            Prefer a direct call? Our Town Properties can be reached through the contact information on ourtownproperties.com.
          </p>
          <p className="text-xs leading-5 text-[#8f8778]">This is broker-reviewed guidance, not an automated appraisal. Not a survey.</p>
        </div>
      ) : null}

      {formError ? (
        <p id={errorId} className="mt-4 rounded-md border border-[#6e162680] bg-[#6e16261f] p-3 text-sm text-[#ffcabd]" role="alert">
          {formError}
        </p>
      ) : null}
    </LuxuryCard>
  );
}

import fs from "node:fs";
import path from "node:path";
import { describe, expect, it } from "vitest";

const root = process.cwd();

function read(file: string) {
  return fs.readFileSync(path.join(root, file), "utf8");
}

describe("AdminOps allocation route guards", () => {
  it("keeps /admin/allocation covered by the admin middleware matcher", () => {
    const middleware = read("src/middleware.ts");
    const rootMiddleware = read("middleware.ts");
    expect(rootMiddleware).toContain('"/admin/:path*"');
    expect(middleware).toContain('"/admin/:path*"');
    expect("/admin/allocation").toMatch(/^\/admin(?:\/.*)?$/);
  });

  it("does not import allocation helpers from public routes", () => {
    const publicFiles = [
      "app/page.tsx",
      "app/home-value/page.tsx",
      "app/sell/page.tsx",
      "app/ask/page.tsx",
      "app/widget/page.tsx",
      "app/embed/ask/page.tsx",
      "app/integrations/ourtownproperties/page.tsx",
      "app/api/leads/route.ts",
    ];

    for (const file of publicFiles) {
      expect(read(file), file).not.toContain("adminAgentAllocationView");
      expect(read(file), file).not.toContain("adminAgentAllocationActions");
      expect(read(file), file).not.toContain("adminAssignmentAudit");
      expect(read(file), file).not.toContain("loadAdminAgentAllocationView");
      expect(read(file), file).not.toContain("assignLeadToAgent");
      expect(read(file), file).not.toContain("unassignLead");
      expect(read(file), file).not.toContain("writeAssignmentAuditEvent");
    }
  });

  it("keeps allocation page free of service role access and delete controls", () => {
    const page = read("app/admin/allocation/page.tsx");
    expect(page).toContain("loadAdminAgentAllocationView");
    expect(page).toContain("assignLeadToAgentAction");
    expect(page).toContain("unassignLeadAction");
    expect(page).toContain("Recent assignment activity");
    expect(page).toContain('href="/admin/leads"');
    expect(page).toContain('href="/admin/reporting"');
    expect(page).not.toMatch(/SUPABASE_SERVICE_ROLE_KEY/);
    expect(page).not.toMatch(/process\.env/);
    expect(page).not.toMatch(/\bdelete\b/i);
    expect(page).not.toMatch(/method:\s*["'`](POST|PATCH|PUT|DELETE)["'`]/);
    expect(page).not.toContain("/api/leads");
  });

  it("keeps allocation read model GET-only and bounded", () => {
    const facade = read("app/lib/adminAgentAllocationView.ts");
    const view = read("app/lib/persistence/supabase/adminAgentAllocationView.ts");
    expect(facade).toContain("persistence/supabase/adminAgentAllocationView");
    expect(view).toContain('new URL("/rest/v1/agents"');
    expect(view).toContain('new URL("/rest/v1/leads"');
    expect(view).toContain("loadRecentAssignmentAuditEvents");
    expect(view).toContain('leadUrl.searchParams.set("limit", String(cappedLimit))');
    expect(view).not.toMatch(/method:\s*["'`](POST|PATCH|PUT|DELETE)["'`]/);
    expect(view).not.toContain("body:");
  });

  it("keeps allocation actions server-only with atomic persistence isolated", () => {
    const routeActions = read("app/admin/allocation/actions.ts");
    const libActions = read("app/lib/adminAgentAllocationActions.ts");
    const adapter = read("app/lib/persistence/supabasePostgrestAdapter.ts");
    const migration = read("supabase/migrations/20260716043829_infra_02_atomic_lifecycle.sql");
    expect(routeActions).toContain('"use server"');
    expect(routeActions).not.toContain("SUPABASE_SERVICE_ROLE_KEY");
    expect(libActions).toContain("mutateAdminAssignment");
    expect(libActions).toContain("mutateAdminAgentOperations");
    expect(libActions).not.toContain("/rest/v1/");
    expect(libActions).not.toContain("SUPABASE_SERVICE_ROLE_KEY");
    expect(libActions).not.toContain("/api/leads");
    expect(libActions).not.toContain("/rest/v1/lead_notifications");
    expect(adapter).toContain('this.rpc("mutate_admin_assignment_v1"');
    expect(adapter).toContain('this.rpc("mutate_admin_agent_operations_v1"');
    expect(migration).toContain("CREATE OR REPLACE FUNCTION public.mutate_admin_assignment_v1");
    expect(migration).toContain("INSERT INTO public.agent_assignments");
    expect(migration).toContain("INSERT INTO public.audit_logs");
    expect(migration).toContain("INSERT INTO public.lead_notifications");
  });
});
